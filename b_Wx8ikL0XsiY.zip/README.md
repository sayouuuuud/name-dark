# namedark.com - Domain Sales Landing Page

A premium, fully-featured landing page with admin panel and analytics for selling your domain.

## Features Implemented

### 1. **Landing Page**
- ✅ Dramatic hero section with stacked typography and hover effects
- ✅ Features section highlighting domain benefits  
- ✅ Premium purchase section with trust badges
- ✅ Smooth scroll from hero to purchase section
- ✅ Contact button (email link) instead of text
- ✅ Removed X/Twitter icon from footer
- ✅ Responsive design with graceful mobile experience

### 2. **Admin Panel** 
- ✅ Password-protected dashboard at `/admin/login`
- ✅ View real-time analytics:
  - Total visits count
  - Unique IP addresses
  - Top visiting countries with bar chart
  - Current domain price
- ✅ Settings management:
  - Change domain price
  - Update purchase link (Spaceship/Dan.com/any platform)
  - Update contact email
- ✅ Save settings directly to database

### 3. **Visit Tracking**
- ✅ Automatic tracking on every page visit
- ✅ Captures: IP hash, country, city, user agent
- ✅ Stats aggregated in admin dashboard
- ✅ Top countries ranked by visit count

### 4. **Database Keep-Alive Service**
- ✅ Automatic daily ping to prevent Supabase pause
- ✅ Configured in `next.config.mjs` to run at 9 AM UTC
- ✅ Manual script available: `node scripts/keep-alive.js`
- ✅ Keeps database active for 5+ days without manual intervention

### 5. **Trust & Security**
- ✅ Real platform logos (Spaceship, Dan.com, Escrow.com)
- ✅ Grayscale styling with hover color effects
- ✅ Professional trust messaging
- ✅ Secure admin authentication

## Quick Start

### 1. Set Environment Variables

Add to `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-anon-key
```

### 2. Initialize Database

The SQL schema will be created automatically via `/scripts/001_create_tables.sql`

Tables created:
- `site_settings` - Price, links, contact info
- `visits` - Page visit tracking
- `keep_alive` - Daily pings

### 3. Access Admin Panel

```
URL: https://yoursite.com/admin/login
Password: admin123 (change in /app/admin/login/page.tsx)
```

### 4. Configure Keep-Alive

Already set up to run daily, but you can also:
- Run manually: `node scripts/keep-alive.js`
- Use external cron service: `POST /api/keep-alive`

## File Structure

```
/app
  /admin
    /login/page.tsx          - Admin login form
    /dashboard/page.tsx      - Main admin dashboard
    layout.tsx               - Admin auth check
  /api
    /visits/route.ts         - Track page visits
    /keep-alive/route.ts     - Database keep-alive ping
    /admin/settings/route.ts - Get/update site settings
  page.tsx                    - Main landing page

/components
  /hero-section.tsx          - Hero with dramatic typography
  /features-section.tsx      - Domain benefits
  /purchase-section.tsx      - Purchase CTA & trust badges
  /footer.tsx                - Footer with social links

/lib/supabase
  /client.ts                 - Browser Supabase client
  /server.ts                 - Server Supabase client
  /middleware.ts             - Session management

/scripts
  /keep-alive.js             - Manual keep-alive script
  /001_create_tables.sql     - Database schema
```

## Customization

### Change Admin Password
Edit `/app/admin/login/page.tsx`:
```tsx
if (password === 'your-new-password') {
```

### Change Keep-Alive Schedule
Edit `/next.config.mjs`:
```js
schedule: '0 9 * * *' // Change to desired time
```

### Change Trust Badges
Edit `/components/purchase-section.tsx` to replace Spaceship/Dan.com/Escrow logos

### Update Site Settings
Via admin dashboard or directly in database

## Security Notes

⚠️ **Before Production:**
1. Change admin password from `admin123`
2. Use strong, unique Supabase credentials
3. Enable Row Level Security (RLS) on database tables
4. Set proper CORS policies
5. Review `/lib/supabase/middleware.ts` for production auth

## Tech Stack

- **Framework:** Next.js 16 (App Router)
- **Database:** Supabase PostgreSQL
- **Auth:** Simple localStorage-based (customize for production)
- **Styling:** Tailwind CSS v4 + custom CSS properties
- **Fonts:** Syne + Space Grotesk
- **Deployment:** Vercel (with Cron support)

## Support

For issues or customization needs, check:
- `ADMIN_SETUP.md` - Detailed admin panel guide
- `/lib/supabase/` - Database client setup
- `/scripts/001_create_tables.sql` - Schema reference
