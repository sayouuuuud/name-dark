'use client'

import { redirect } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [isAuthed, setIsAuthed] = useState<boolean | null>(null)

  useEffect(() => {
    const adminPassword = localStorage.getItem('admin_auth')
    if (adminPassword === 'authed') {
      setIsAuthed(true)
    } else {
      redirect('/admin/login')
    }
  }, [])

  if (isAuthed === null) return null

  return <>{children}</>
}
